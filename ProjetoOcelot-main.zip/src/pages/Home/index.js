import { Image, TextInput, View, TouchableOpacity, Text } from 'react-native'
import styles from './styles'
import { Link } from '@react-navigation/native';



export default function Home(){
    return (
        <View style={styles.container}>
            <Image 
                source={require('../../../assets/Doutor.png')} 
                style={styles.logo}
            />
            <Text style={styles.welcomeText}>
                Olá, Doutor Fulano de Tal.
            </Text>
            <View style={styles.viewLinks}>
                <Link to={{screen: 'LoginPage'}}>
                    <Text style={styles.LinkBtn}>Voltar para o Login</Text>
                </Link>
            </View>
        </View>
    )
}